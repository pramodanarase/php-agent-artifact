<html><title>Start APM PHP Probe</title>
<body><p>Starting APM PHP Probe</p>
<?php
wily_php_agent_start(); 
?>
</body>
</html>

